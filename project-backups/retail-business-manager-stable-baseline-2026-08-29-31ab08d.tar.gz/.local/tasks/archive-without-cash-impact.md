# Archive Without Cash Impact

## What & Why
Change cash closing into a repeatable archive-only operation. Each closing captures only the currently unarchived daily-journal events while preserving the local calendar date, all source records, and every currency balance.

## Done looks like
- Closing the cash box creates a fixed snapshot without creating or modifying transactions, debts, payments, customers, or currency balances.
- The same store can close multiple times on the same local date, numbered in chronological order.
- Each closing contains only events created since the preceding closing, and archived events disappear from the current daily journal.
- New events created later on the same date reappear in the journal and can be captured by a subsequent closing.
- The local date changes only at midnight; events after midnight belong only to the new calendar date.
- Archives remain isolated by store and preserve all event details already shown by the daily journal.
- The required multi-closing, midnight-boundary, snapshot-integrity, store-isolation, and unchanged-currency-balance unit tests pass.

## Out of scope
- Deleting, editing, reopening, exporting, or cloud-syncing archives.
- Changes to currency calculations, dashboard layout, FAB flows, customers, debts, payments, settings, login, navigation, reports, or accounting behavior.
- Expo, Metro, browser, Playwright, screenshots, visual testing, E2E, or preview restarts.

## Steps
1. **Repeatable archive records** -- Replace the one-record-per-date duplicate rule with distinct store-scoped closing records that retain the local calendar date and deterministic closing order, while remaining compatible with safely readable existing snapshots.
2. **Unarchived journal view** -- Exclude event IDs already captured by archive snapshots from the current daily journal without deleting or mutating any source business records.
3. **Immediate UI refresh** -- Use the existing shared closing action to notify both journal entry points after a successful closing so archived events disappear and later same-day events appear normally.
4. **Archive presentation** -- Present multiple closings under the same date with their closing numbers and immutable per-closing snapshots, without redesigning unrelated screens.
5. **Focused verification** -- Add the specified same-day multi-closing and midnight tests, explicitly assert unchanged TRY, USD, and EUR balances, and run only TypeScript, unit tests, and git diff validation.

## Relevant files
- `artifacts/retail-business-manager/services/storage.ts:194-457`
- `artifacts/retail-business-manager/services/dailyClosing.ts`
- `artifacts/retail-business-manager/types/business.ts:84-90`
- `artifacts/retail-business-manager/components/DailyClosingAction.tsx`
- `artifacts/retail-business-manager/app/index.tsx`
- `artifacts/retail-business-manager/app/cash.tsx`
- `artifacts/retail-business-manager/app/archive.tsx`
- `artifacts/retail-business-manager/tests/archives.test.ts`
- `artifacts/retail-business-manager/tests/daily-journal.test.ts`
- `artifacts/retail-business-manager/tests/transactions.test.ts`