# Customer Settlement And Credit Flow

## What & Why
تفعيل تدفق الآجل من زر الصفحة الرئيسية وتدفق السداد من صفحة العميل فوق أساس الديون المحلي الموجود. الآجل ينشئ Debt فقط، بينما السداد يخفض الدين المتبقي ويسجل قبضًا نقديًا cash_in مستقلًا في اليومية، مع فصل كامل حسب المتجر والعميل والعملة.

## Done looks like
- زر آجل الموجود داخل FAB يفتح الحوار الحالي لاختيار عميل موجود، وإدخال مبلغ موجب، واختيار عملة، ثم يحفظ Debt مرتبطًا بـcustomerId وstoreId.
- لا ينشئ الآجل cash_in أو cash_out، ولا يزيد رصيد الصندوق، ولا يضيف شيئًا إلى Daily Journal.
- صفحة تفاصيل العميل تحتوي زر سداد واضحًا دون إعادة تصميم الصفحة.
- السداد يعرض العملات التي لها دين متبقٍ، ويرفض المبلغ الفارغ أو غير الرقمي أو غير الموجب أو الأكبر من المتبقي.
- السداد الجزئي والكامل يحدّثان المتبقي بشكل صحيح ولا يسمحان بقيمة سالبة، مع بقاء سجل الدين الأصلي دون حذف.
- كل دفعة محفوظة كسجل Payment مستقل مرتبط بالمتجر والعميل والعملة والمبلغ والتاريخ، ويظهر سجل الدفعات الأحدث أولًا.
- كل سداد ينشئ Transaction من نوع cash_in بنفس المتجر والعملة والمبلغ، ويظهر في Daily Journal ويزيد رصيد العملة المعنية فقط.
- TRY وUSD وEUR وغيرها تبقى مستقلة دون تحويل أو جمع موحد، وتبقى بيانات المتاجر والعملاء معزولة بعد إعادة التحميل.
- كشف WhatsApp الحالي يعرض الدين المتبقي حسب العملة فقط إذا أمكن تحديثه مباشرة دون إعادة بناء نظام المشاركة.
- الإدخال العشري يدعم 1.5 و1,5 وفق اللغة الحالية دون تحويل 1,5 إلى 15، مع ترجمات عربية وإنجليزية وتركية ودعم RTL/LTR.
- لا يتغير FAB أو Dashboard أو Currency Boxes أو Settings أو Customer Editing/Deletion إلا بالحد الأدنى اللازم للتدفقين، ولا يُضاف أي زر أو منطق جديد للسداد خارج صفحة العميل.

## Out of scope
- إعادة بناء نظام Debt الموجود أو إنشاء نظام تخزين جديد.
- Firebase أو Backend أو Authentication أو Google Drive أو Archive أو Closing Cash أو Notifications أو Permissions.
- المبيعات أو المشتريات أو المخزون أو المنتجات أو الموردين أو التقارير أو تحويل العملات أو أسعار الصرف.
- الدفع الجزئي كنوع عمل تجاري منفصل، أو إلغاء/حذف/تعديل الديون والدفعات، أو سجل مالي كامل خارج المطلوب.
- إعادة تصميم FAB أو Customer Details أو Glass/Liquid Glass أو Navigation أو Theme.
- Expo أو Expo Web أو Metro أو Browser أو Browser Automation أو Playwright أو Screenshots أو Visual Testing أو E2E.

## Steps
1. **Settlement data foundation** -- استخدم نموذج Payment الموجود وأضف أقل الحقول/التحقق اللازمين لتسجيل دفعة مستقلة، ثم أضف عمليات التخزين المحلية للدفعات مع مفتاح مستقل وعزل المتاجر والتعامل الآمن مع JSON والسجلات الفاسدة.
2. **Debt settlement calculations** -- أضف منطقًا نقيًا لتجميع الديون والدفعات حسب customerId وcurrency وحساب المتبقي دون دمج العملات، مع رفض السداد الذي يتجاوز الرصيد المتبقي ومنع القيم السالبة.
3. **Home credit flow** -- اربط إجراء آجل الموجود في FAB بحوار يستخدم العملاء الحاليين ونظام العملات ومحلل المبالغ المحلي، ثم أنشئ Debt فقط مع حفظه وبدون تغيير أي Transaction أو رصيد نقدي.
4. **Customer settlement flow** -- أضف زر سداد وحوارًا داخل صفحة العميل يختار عملة ذات متبقي ثم مبلغًا، ويحفظ Payment ويحدّث العرض مباشرة مع بقاء سجل الديون الأصلي محفوظًا.
5. **Cash integration** -- بعد نجاح حفظ Payment فقط، أنشئ cash_in عبر نظام Transaction الحالي بنفس المتجر والعملة والمبلغ، بحيث يظهر في اليومية ويؤثر على رصيد العملة دون ربط الآجل نفسه بالنقد.
6. **Customer display and statement** -- اعرض المتبقي المستقل لكل عملة، وسجل الدفعات الأحدث أولًا، وحدث نص WhatsApp الحالي فقط إن كان ذلك مباشرًا باستخدام المتبقي المحسوب؛ لا تبنِ نظام مشاركة جديدًا.
7. **Focused verification** -- أضف اختبارات وحدات لتدفق آجل الصفحة الرئيسية والسداد الجزئي والكامل والتجاوز والعملات والعزل والتخزين والبيانات التالفة وترتيب Payment وتكامل cash_in وعدم إنشاء Cash عند الآجل، ثم شغّل TypeScript والاختبارات وgit diff --check فقط.

## Relevant files
- `artifacts/retail-business-manager/types/business.ts`
- `artifacts/retail-business-manager/services/storage.ts`
- `artifacts/retail-business-manager/context/StoreContext.tsx`
- `artifacts/retail-business-manager/app/customer/[id].tsx`
- `artifacts/retail-business-manager/app/index.tsx`
- `artifacts/retail-business-manager/components/FloatingQuickActions.tsx`
- `artifacts/retail-business-manager/constants/currencies.ts`
- `artifacts/retail-business-manager/constants/i18n.ts`
- `artifacts/retail-business-manager/tests/customers.test.ts`
- `artifacts/retail-business-manager/tests/storage.test.ts`
- `artifacts/retail-business-manager/tests/transactions.test.ts`
- `artifacts/retail-business-manager/tests/debts.test.ts`