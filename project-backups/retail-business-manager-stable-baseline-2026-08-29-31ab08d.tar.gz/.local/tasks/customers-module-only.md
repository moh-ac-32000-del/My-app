# Customers Module Only

## What & Why
تفعيل قسم العملاء فقط في تطبيق Expo الحالي، مع تخزين محلي مستقل وبنية قابلة للتوسع لاحقًا، دون تغيير التصميم أو البنية العامة أو بدء أي وحدة مالية.

## Scope
- استخدام Customer الموجود في types/business.ts، وتعديله فقط إذا كان ذلك ضروريًا لحقول العميل الأساسية: id ثابت مستقل عن الاسم، storeId، name، phone/address/notes الاختيارية، createdAt، updatedAt.
- حتى مع المستخدم المحلي الواحد يجب أن تحتوي سجلات Customer على storeId. استخدم Store ID الموجود في البنية الحالية إن كان متاحًا. إن لم يوجد Store ID فعلي، استخدم الآلية/القيمة الحالية للمشروع دون إنشاء نظام هوية أو Users أو Workspaces.
- إضافة عمليات تخزين محلية صغيرة مستقلة عن StoreProfile عبر services/storage.ts، بمفتاح جديد واضح مثل loadCustomers/saveCustomers، مع Runtime Validation آمنة لا تكسر التطبيق ولا تسقط السجلات الصحيحة بسبب سجل تالف.
- تفعيل app/customers.tsx بدل Under Development مع AppShell والتصميم الحالي: Header مترجم، عدد العملاء، بحث بالاسم والهاتف، Glass Cards، Empty State، وزر إضافة عميل.
- إضافة عميل عبر Modal/Dialog بالنمط الموجود، مع اسم إجباري ورسالة Validation مترجمة، وتحديث القائمة والعدد والحفظ فورًا.
- فتح تفاصيل العميل عبر مسار Expo Router مناسب مثل app/customer/[id].tsx، مع الاسم والهاتف والعنوان والملاحظات وتاريخ الإنشاء، دون مبالغ أو أرصدة أو دين وهمي.
- دعم تعديل العميل من صفحة التفاصيل عبر Modal/Dialog، وتحديث القائمة والتخزين.
- دعم حذف العميل فقط بعد Confirmation Dialog مترجم؛ لا حذف مباشر دون تأكيد.
- إضافة جميع النصوص الجديدة إلى constants/i18n.ts بالعربية والإنجليزية والتركية، مع RTL/LTR عبر النظام الحالي.
- إضافة اختبارات وحدات صغيرة للإضافة والتحميل والتعديل والبحث بالاسم والهاتف ورفض الاسم الفارغ والبيانات غير الصالحة، دون E2E أو Playwright.

## Data Safety
- التعامل بأمان مع JSON التالف أو بيانات Customers غير الصالحة من AsyncStorage.
- لا يؤدي JSON تالف إلى Crash.
- لا يؤدي سجل واحد غير صالح إلى فقدان العملاء الصحيحين.
- استخدام Runtime Validation البسيط الموجود من Task #2، دون إضافة Validation framework جديد.

## Constraints
- لا إعادة بناء ولا Refactor كبير.
- لا تغيير في Black/Dark Glass/Liquid Glass أو Theme أو Accent أو i18n أو RTL/LTR أو Currency أو Quick Currencies أو FAB أو Bottom Navigation أو Splash أو Login أو Settings.
- لا Firebase، ولا Authentication حقيقي، ولا Workspaces أو Roles أو Permissions.
- لا Reminders أو Notifications أو Daily Journal أو Cash Box logic.
- لا Debt أو Payment أو Transaction أو Sales أو Purchases logic.
- لا Inventory أو Products أو Suppliers أو Exchange Rate أو Currency Conversion.
- لا استخدام للعملة أو مبالغ أو Balance داخل Customer.
- لا عمليات AsyncStorage مباشرة داخل صفحات العملاء.
- لا تغيير في مفاتيح التخزين الحالية.
- لا إضافة مكتبات جديدة إلا عند ضرورة مباشرة؛ لا Web-only dependencies.
- القائمة صغيرة، لذلك لا نحتاج تحسينات Performance معقدة. اجعل المكونات بسيطة وقابلة لإعادة الاستخدام.

## Navigation
- الالتزام بسياسة التنقل الموجودة في المشروع.
- لا تغيير Navigation العامة.
- عند فتح Customer Details يمكن استخدام push.
- عند العودة استخدم Back الطبيعي.
- لا تعدل Bottom Navigation أو AppShell إلا إذا كان هناك خطأ مباشر يمنع صفحة العملاء من العمل.

## Allowed Files
يمكن تعديل الملفات التالية فقط، إلا لسبب مباشر وضروري:
- artifacts/retail-business-manager/app/customers.tsx
- artifacts/retail-business-manager/app/customer/[id].tsx أو المسار المناسب
- artifacts/retail-business-manager/types/business.ts عند الضرورة
- artifacts/retail-business-manager/services/storage.ts
- artifacts/retail-business-manager/constants/i18n.ts
- مكونات Customer الصغيرة داخل artifacts/retail-business-manager/components/
- ملفات الاختبارات اللازمة

## Acceptance Criteria
- يمكن إضافة عميل باسم إجباري، ويظهر فورًا في القائمة مع العدد الصحيح.
- يمكن البحث عن العميل بالاسم أو رقم الهاتف.
- يمكن فتح تفاصيل العميل وتعديل بياناته.
- يمكن حذف العميل فقط بعد التأكيد المترجم.
- Customer IDs ثابتة ولا تعتمد على اسم العميل.
- Customer records تحتوي storeId باستخدام البنية الحالية دون بناء نظام Workspaces أو Users.
- بيانات العملاء مستقلة عن StoreProfile وتبقى بعد Reload.
- JSON أو سجل Customer غير صالح لا يسبب Crash ولا يمنع العملاء الصحيحين من الظهور.
- Empty State يعمل مع زر إضافة.
- العربية RTL، الإنجليزية LTR، والتركية LTR.
- التصميم متوافق مع Black/Dark Glass/Liquid Glass الحالي.
- لا تظهر أي وظائف مالية أو ميزات خارج قسم العملاء.
- لا يوجد منطق دين أو سداد أو Firebase أو Authentication حقيقي أو مخزون أو سعر صرف.
- typecheck وgit diff --check والاختبارات الجديدة تمر.

## Manual Verification
- على Expo وفي سياق نظيف:
  1. اختيار العربية، فتح Customers، إضافة عميل، البحث عنه، فتح تفاصيله، تعديل بياناته، ثم إعادة تحميل التطبيق والتأكد من بقاء البيانات.
  2. تغيير اللغة إلى English والتأكد من ترجمة صفحة العملاء وLTR.
  3. تغيير اللغة إلى Turkish والتأكد من ترجمة الصفحة وLTR.
  4. العودة للعربية والتأكد من RTL.
  5. التحقق من عدم تأثر Settings والعملات وFAB والتنقل العام.

## Checks
بعد التنفيذ شغّل بالترتيب:
- pnpm --filter @workspace/retail-business-manager run typecheck
- git diff --check
- الاختبارات الجديدة فقط أو Script الاختبارات الموجود للمشروع

## Out of Scope
كل ما عدا Customer Module، بما في ذلك Firebase وAuthentication الحقيقي والديون والسداد والمعاملات والتذكيرات والصندوق والمخزون والمنتجات والموردين والتحويلات المالية والمساحات والصلاحيات، وأي مرحلة لاحقة.

## Stop Rule
إذا ظهرت مشكلة خارج نطاق Task #3، لا تبدأ بإصلاحها تلقائيًا. إذا كانت تمنع إكمال Customer Module، أبلغ المستخدم أولًا. لا تبدأ Refactor كبيرًا، ولا تنشئ مرحلة جديدة، وبعد الانتهاء قدّم تقريرًا مختصرًا بالملفات المعدلة، والتنفيذ، والاختبارات، ونتائج TypeScript وgit diff --check والاختبار العملي وأي مشاكل متبقية، ثم توقف.

## Mandatory Constraints Before Execution

### Preserve Existing Storage Service
- استخدم services/storage.ts الموجود أصلًا والذي أُنشئ في Task #2.
- مدّد الخدمة بأقل تغيير ممكن، وأضف فقط loadCustomers() وsaveCustomers() عند الحاجة.
- ممنوع إنشاء خدمة تخزين ثانية.
- ممنوع استبدال أو إعادة تسمية خدمة التخزين الحالية.
- ممنوع تحويلها إلى Repository أو Adapter أو DI أو Factory أو Data Layer كبيرة.
- لا تغيّر سلوك حفظ StoreProfile أو اللغة أو العملة أو Accent أو Quick Currencies أو Demo Auth.
- لا تغيّر مفاتيح AsyncStorage الحالية إلا إذا كان ذلك ضروريًا للغاية.

### Inspect Before Modifying
قبل تعديل أي ملف من ملفات التطبيق، يجب فحص النسخ الحالية الفعلية من:
- services/storage.ts
- context/StoreContext.tsx
- types/business.ts
- app/customers.tsx

لا تفترض بنية هذه الملفات اعتمادًا على وصف Task #2 السابق؛ يجب العمل وفق الكود الموجود فعليًا.

### Strict Customer-Only Boundary
تبقى Task #3 محصورة تمامًا في Customer Module. ممنوع بدء أي عمل متعلق بـ Debt أو Payment أو Transaction أو Daily Journal أو Cash Box أو Reminder أو Notification أو Firebase أو Authentication أو Workspace أو Role أو Permission أو Inventory أو Product أو Supplier أو Exchange Rate أو Currency Conversion.
