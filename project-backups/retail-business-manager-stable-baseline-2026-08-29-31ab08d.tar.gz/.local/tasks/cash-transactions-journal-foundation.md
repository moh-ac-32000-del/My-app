# Cash Transactions Journal Foundation

## What & Why
Build the first real cash transaction foundation for the existing Expo retail manager. Replace the current preview-only cash-in/cash-out behavior with store-scoped local transactions that can be saved, reloaded, displayed in the daily journal, and used for independent per-currency net balances.

## Done looks like
- Users can create a cash-in transaction from the existing FAB flow.
- Users can create a cash-out transaction from the existing FAB flow.
- Each saved transaction has a stable unique ID, storeId, cash_in or cash_out type, one valid currency, a positive amount, an optional note, and timestamps.
- Transactions persist locally, survive reloads, remain isolated by store, and do not overwrite another store records.
- Corrupted transaction JSON fails safely without crashing or destroying valid records.
- The daily journal shows current-store transactions newest first with translated type, amount, currency, note, and date/time.
- TRY and USD dashboard cash balances are calculated independently from saved transactions without conversion or combining currencies.
- Arabic remains RTL; English and Turkish remain LTR; existing FAB styling, navigation, settings, customer module, archive, login, and splash behavior remain unchanged.
- Unit coverage verifies creation, persistence, validation, store isolation, per-currency net totals, corrupted JSON handling, and stable unique IDs.

## Out of scope
- Debt, payment, sales, purchases, inventory, products, suppliers, customers or customer relations, exchange rates, currency conversion, Firebase, authentication changes, backend APIs, deletion, editing, closing cash, archive behavior, notifications, permissions, or redesigning the dashboard/navigation.
- No new storage abstraction, repository, dependency-injection layer, or data layer.
- No Expo, browser automation, Playwright, E2E, or visual testing for this task.

## Steps
1. **Transaction model and validation** -- Narrow the active cash transaction model to the required cash_in and cash_out domain fields, while keeping unrelated future domain interfaces untouched. Add small pure helpers for validating transaction input and computing independent per-currency net totals so invalid amounts, currencies, and IDs are handled deterministically.
2. **Local transaction persistence** -- Extend the existing storage module with a new transaction key and direct load/save functions. Normalize stored records defensively, ignore malformed records or corrupted JSON safely, require storeId and valid CurrencyCode values, and merge writes so saving one store never removes another store transactions.
3. **Shared transaction state** -- Connect transaction loading and creation to the existing store context only as much as needed for current-store display, save, and reload behavior; do not alter settings, customer persistence, authentication, or unrelated state.
4. **Daily journal screen** -- Activate the current cash/daily-journal route using existing AppShell and glass components. Render current-store transactions newest first with translated cash-in/cash-out labels, positive formatted amounts, currency codes, optional notes, and localized date/time; provide a translated empty state when no records exist.
5. **FAB cash flows** -- Preserve the current FAB/menu design and connect only the existing inside and outside actions to a modal with amount, current/quick currency selection, optional note, validation, and save/cancel behavior. Store cash-out amounts as positive values and use the transaction type rather than negative numbers; leave credit and settlement as non-functional UI.
6. **Dashboard wiring** -- Replace only the existing placeholder TRY/USD cash balance values and recent-activity empty placeholder where directly supported by stored transactions. Keep currencies separate and leave the rest of the dashboard unchanged.
7. **Unit verification** -- Add focused unit tests for both transaction types, persistence/reload, validation failures, currency validation, store isolation, per-currency totals without merging currencies, corrupted JSON safety, and stable unique IDs. Run only TypeScript, the relevant unit tests, and git diff --check.

## Relevant files
- `artifacts/retail-business-manager/types/business.ts`
- `artifacts/retail-business-manager/services/storage.ts`
- `artifacts/retail-business-manager/context/StoreContext.tsx`
- `artifacts/retail-business-manager/app/cash.tsx`
- `artifacts/retail-business-manager/app/index.tsx`
- `artifacts/retail-business-manager/components/FloatingQuickActions.tsx`
- `artifacts/retail-business-manager/components/AppShell.tsx`
- `artifacts/retail-business-manager/constants/currencies.ts`
- `artifacts/retail-business-manager/constants/i18n.ts`
- `artifacts/retail-business-manager/tests/storage.test.ts`
- `artifacts/retail-business-manager/tests/customers.test.ts`