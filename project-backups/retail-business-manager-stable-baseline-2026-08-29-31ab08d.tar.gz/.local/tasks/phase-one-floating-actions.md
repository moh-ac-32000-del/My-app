# First-batch quick actions

## What & Why
Implement the first UI/UX batch for the existing Expo retail manager: a shared floating action button, a custom glass quick-actions menu, preview-only cash-in/cash-out dialogs, and persistent quick-currency selection. Keep all existing language, RTL/LTR, theme, currency, AsyncStorage, and navigation systems intact.

## Done looks like
- Main app screens show a responsive floating action button that respects safe areas and never covers the bottom navigation or important content.
- Tapping it opens and closes a compact animated custom Glass/Liquid quick-actions menu with translated actions: cash in, cash out, credit, settlement, and quick currencies.
- Cash in and cash out open preview-only forms for amount, current currency, optional note, confirm, and cancel; confirm does not persist data or perform accounting.
- Settings lets the user select any subset of TRY, USD, EUR, GBP, SAR, AED, and SYP as quick currencies and saves that selection in AsyncStorage.
- The quick-currencies action displays only the saved selection, with no exchange-rate or conversion behavior; selecting a currency changes the currency label only and never the numeric amount.
- Arabic, English, and Turkish labels, direction, ordering, and controls work consistently without hardcoded UI strings.
- Existing Black/Dark Glass/Liquid Glass styling, accent colors, theme, bottom navigation, and existing routes remain intact.
- Interactive testing covers the requested flows on a mobile-sized Expo preview, plus TypeScript and diff checks.

## Out of scope
- Firebase, real authentication, real financial/accounting operations, database persistence, debt or settlement logic.
- Inventory, products, IMEI, suppliers, exchange rates, currency conversion, sales, purchases, or any second development batch.
- New backend APIs, new native modules, or platform-specific UI.

## Steps
1. **Shared state and persistence** -- Extend the existing shared store/profile persistence with a typed quick-currency selection and safe defaults, without changing the existing currency value or conversion behavior.
2. **Localization and testability** -- Add translated labels and accessibility/test identifiers needed for the new actions, dialog states, quick-currency settings, and empty-selection state in Arabic, English, and Turkish.
3. **Floating action surface** -- Build the shared responsive floating action surface inside the existing app shell, including safe-area-aware placement, RTL/LTR mirroring, glass styling, and smooth open/close animation.
4. **Preview cash dialogs** -- Add custom preview-only cash-in and cash-out dialogs with amount, current-currency display, optional note, confirm/cancel controls, validation feedback, and explicit non-persistence behavior. Add translated menu states for credit and settlement as UI-only actions without implementing their business flows.
5. **Quick currencies** -- Add the Settings quick-currency selector and connect the floating quick-currencies action to a compact custom picker that only shows the persisted selection, preserving numeric values and avoiding exchange/conversion logic.
6. **Verification** -- Run the existing Expo workflow and perform an end-to-end mobile UI pass across Arabic, English, Turkish, RTL/LTR, menu/dialog interactions, quick-currency persistence after reload, theme/navigation integrity, and the required static checks.

## Relevant files
- `artifacts/retail-business-manager/components/AppShell.tsx`
- `artifacts/retail-business-manager/components/QuickActions.tsx`
- `artifacts/retail-business-manager/app/index.tsx`
- `artifacts/retail-business-manager/app/settings.tsx`
- `artifacts/retail-business-manager/context/StoreContext.tsx`
- `artifacts/retail-business-manager/types/business.ts`
- `artifacts/retail-business-manager/constants/i18n.ts`
- `artifacts/retail-business-manager/constants/currencies.ts`
- `artifacts/retail-business-manager/constants/colors.ts`
- `artifacts/retail-business-manager/hooks/useI18n.ts`