# تمهيد آمن قبل ميزة العملاء

## النطاق
تنفيذ مرحلة تمهيدية صغيرة على تطبيق Expo الحالي، دون إعادة بناء ودون تغيير السلوك أو التصميم أو الميزات الحالية.

## المطلوب
1. إصلاح مزامنة حالة Settings مع التحميل غير المتزامن في StoreContext حتى لا تكتب القيم المحلية القديمة فوق profile الأحدث.
2. إضافة Types فقط إلى types/business.ts للكيانات Customer وTransaction وPayment وDebt وReminder، بحيث تكون قابلة للتوسع مستقبلًا مع store/user scoping، دون صفحات أو وظائف أو Collections جديدة.
3. نقل تفاصيل AsyncStorage الأساسية إلى خدمة صغيرة محلية، مع الحفاظ على مفاتيح التخزين والسلوك الحالي وعدم حذف البيانات.
4. إضافة Runtime Validation خفيفة لبيانات StoreProfile المحملة من JSON، مع قيم افتراضية آمنة والحفاظ على الحقول الصحيحة. لا تتم إضافة `schemaVersion` إلا إذا أثبت الفحص أنها مطلوبة فعلًا للترحيل الحالي؛ وإلا تُترك دون إضافة.
5. إضافة اختبارات وحدات صغيرة للتخزين (save/load/corrupted data)، والعملات، وحفظ/تحميل profile. استخدام أبسط بيئة اختبار مناسبة دون Playwright أو E2E suite كبيرة.
6. تشغيل typecheck وgit diff --check والاختبارات، ثم فحص عملي لتدفق التحميل وSettings واللغة والعملة وAccent والعملات السريعة بعد إعادة التحميل.

## قيود غير قابلة للتفاوض
- لا Firebase.
- لا Authentication حقيقي.
- لا صفحات أو UI جديدة للعملاء أو الديون أو السداد أو المعاملات.
- لا إشعارات أو Workspaces أو Roles أو Permissions.
- لا مخزون أو منتجات أو موردين.
- لا Exchange Rate أو Currency Conversion.
- لا تغيير في Black/Dark Glass/Liquid Glass أو اللغات أو RTL/LTR أو العملات أو العملات السريعة أو FAB أو Navigation أو Splash أو Login الحالي.
- لا تغيير في مفاتيح AsyncStorage إلا عند الضرورة القصوى، ولا حذف للبيانات الحالية.
- لا Web-only dependencies.
- طبقة AsyncStorage يجب أن تبقى صغيرة وبسيطة جدًا لعزل عمليات القراءة والكتابة الحالية فقط؛ ممنوع Repository patterns أو dependency injection أو adapters أو factories أو data layer كبيرة.

## معيار الاكتمال
- Settings لا تحفظ stale profile بعد hydration.
- البيانات الصحيحة تبقى بعد save/load/reload.
- JSON التالف لا يكسر التطبيق ويعود إلى defaults الآمنة مع الاحتفاظ بما يمكن التحقق منه.
- Types واضحة فقط، بلا منطق تشغيل.
- اختبارات الوحدات الجديدة تمر.
- typecheck وgit diff --check يمران.
- لا تغيير بصري أو سلوكي خارج الإصلاحات الداخلية المطلوبة.

## الملفات المحتملة
- artifacts/retail-business-manager/app/settings.tsx
- artifacts/retail-business-manager/context/StoreContext.tsx
- artifacts/retail-business-manager/types/business.ts
- artifacts/retail-business-manager/constants/currencies.ts
- artifacts/retail-business-manager/services/ (خدمة تخزين صغيرة)
- إعداد الاختبارات داخل artifacts/retail-business-manager فقط إذا كان ضروريًا
