# Customer Debt Foundation Only

## What & Why
إضافة أساس محلي صغير لتسجيل دين على عميل موجود، مرتبط بمتجر وعميل وعملة ومبلغ، مع عرض إجماليات الدين وسجل الديون داخل صفحة تفاصيل العميل فقط. يجب أن يبقى الدين مستقلًا تمامًا عن المعاملات النقدية وصندوق العملات واليومية.

## Done looks like
- يمكن من صفحة تفاصيل العميل فتح حوار إضافة آجل وإدخال مبلغ موجب واختيار عملة ثم حفظه أو إلغاؤه.
- كل دين محفوظ يحتوي على معرّف ثابت وفريد، storeId، customerId، عملة صحيحة، مبلغ موجب، وتاريخي إنشاء وتحديث صالحين.
- الديون تحفظ في مفتاح AsyncStorage مستقل، وتبقى بيانات المتاجر والعملاء والمعاملات الحالية دون تغيير.
- تحميل متجر يعرض ديونه فقط، وحفظ متجر لا يحذف ديون متجر آخر.
- JSON التالف لا يسبب Crash، والسجل التالف داخل قائمة يتم تجاهله مع إبقاء السجلات الصحيحة.
- صفحة العميل تعرض إجماليًا مستقلًا لكل عملة وسجل الديون الأحدث أولًا، دون جمع العملات المختلفة.
- رسائل الإدخال والأخطاء تعمل بالعربية RTL والإنجليزية والتركية LTR.
- مشاركة كشف العميل الحالية لا يعاد بناؤها؛ تُحدّث فقط إذا أمكن تمرير إجماليات الدين الحالية مباشرة دون توسيع النظام.
- لا يظهر الدين في Dashboard أو Daily Journal أو Cash In/Cash Out أو أي رصيد نقدي.
- اختبارات وحدات مركزة تغطي الإنشاء والتحقق والحفظ والعزل والإجماليات والتصفية حسب العميل.

## Out of scope
- السداد أو الدفع أو التسوية أو الدفعات الجزئية أو الكاملة.
- كشف حساب مالي كامل أو أرشيف أو إغلاق صندوق.
- ربط الدين بالمعاملات النقدية أو المبيعات أو المشتريات أو المخزون أو المنتجات أو الموردين.
- Firebase أو Backend أو Authentication أو Google Drive أو Notifications أو Permissions.
- تعديل Dashboard أو Daily Journal أو FAB أو Settings أو قائمة العملاء أو تعديل/حذف العميل أو التنقل أو التصميم العام.
- إعادة بناء مشاركة WhatsApp؛ تُترك كما هي إذا كان تحديثها يتطلب نظامًا جديدًا.
- إنشاء Repository أو Adapter أو Factory أو Data Layer أو State Management جديد.
- Expo أو Metro أو Browser Automation أو Playwright أو Screenshots أو Visual Testing أو E2E.

## Steps
1. **Debt foundation and validation** -- عدّل نموذج الدين الحالي بالحد الأدنى ليعبّر عن دين مفتوح أساسي يحتوي فقط على الحقول المطلوبة، وأضف إنشاءً وتحققًا حتميًا يرفض المعرفات والمتجر والعميل والعملات غير الصحيحة والمبالغ غير الموجبة والتواريخ غير الصالحة.
2. **Local debt persistence** -- أضف مفتاح تخزين مستقلًا وعمليات تحميل وحفظ داخل خدمة التخزين الحالية. نظّم السجلات بأمان، تجاهل السجل الفاسد منفردًا، تعامل مع JSON التالف دون Crash، وادمج الكتابة مع بيانات المتاجر الأخرى بدل حذفها.
3. **Customer debt entry** -- أضف إلى صفحة تفاصيل العميل إجراء إضافة آجل باستخدام Modal/Dialog والمكونات الحالية، مع حقل مبلغ رقمي، اختيار من نظام العملات الحالي، وأزرار حفظ وإلغاء ورسائل تحقق مترجمة.
4. **Customer debt display** -- حمّل ديون المتجر والعميل الحالي عند فتح/عودة صفحة التفاصيل، واعرض إجماليًا مستقلًا لكل عملة وسجل الديون الأحدث أولًا. لا تعرض أي سجل لعميل آخر ولا تجمع العملات.
5. **Statement compatibility** -- افحص مشاركة كشف العميل الحالية، وحدّث نصها فقط إذا أمكن استخدام إجماليات الديون المحمّلة مباشرة؛ وإلا اترك المشاركة دون توسعة وأبلغ بحدودها.
6. **Focused verification** -- أضف اختبارات وحدات للإنشاء والمعرفات والتحقق والحفظ/التحميل وJSON التالف والسجل الفاسد والعزل حسب المتجر والعميل وإجماليات العملات، ثم شغّل TypeScript والاختبارات وgit diff --check فقط.

## Relevant files
- `artifacts/retail-business-manager/types/business.ts`
- `artifacts/retail-business-manager/services/storage.ts`
- `artifacts/retail-business-manager/app/customer/[id].tsx`
- `artifacts/retail-business-manager/constants/i18n.ts`
- `artifacts/retail-business-manager/constants/currencies.ts`
- `artifacts/retail-business-manager/components/AppShell.tsx`
- `artifacts/retail-business-manager/components/CustomerFormModal.tsx`
- `artifacts/retail-business-manager/tests/customers.test.ts`
- `artifacts/retail-business-manager/tests/storage.test.ts`