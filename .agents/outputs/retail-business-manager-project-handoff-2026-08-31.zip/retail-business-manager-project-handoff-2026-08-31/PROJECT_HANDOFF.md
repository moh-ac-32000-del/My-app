# Retail Business Manager — Project Handoff

**Snapshot date:** 2026-08-31 (Europe/Istanbul)
**Purpose:** Backup and handoff only. This document describes the exact implementation state captured in this archive. It is not a migration plan and does not authorize new work.

## Scope and fidelity

This archive contains the current source and configuration snapshot for the Retail Business Manager workspace: the Expo application, Firebase Functions source, current API server artifact, mockup-sandbox artifact, tests, Firebase configuration, and Firestore Security Rules.

Installed dependency directories, generated build output, logs, environment files, private keys, credentials, and secret values are intentionally excluded. Environment-variable names remain where they are part of the source contract; their values are never included. Secret-like assignments in the copied `.replit` file are redacted.

The project source was not modified to create this package. This document was created in the temporary packaging area and exists only inside the archive.

## Project structure

```text
workspace/
├── package.json
├── pnpm-lock.yaml
├── pnpm-workspace.yaml
├── .replit                         # copied with secret-like values redacted
├── replit.md
└── artifacts/
    ├── retail-business-manager/
    │   ├── app/                     # Expo Router screens/routes
    │   ├── components/              # shared UI and business actions
    │   ├── constants/               # colors, currencies, localization
    │   ├── context/                 # StoreContext
    │   ├── data/                    # Firestore collection contracts
    │   ├── functions/src/            # trusted Firebase Functions source
    │   ├── hooks/
    │   ├── services/                # Auth, Firebase, local storage, backup, bootstrap
    │   ├── tests/                   # unit and Rules test sources
    │   ├── types/                   # business, Space, trusted bootstrap contracts
    │   ├── app.json
    │   ├── firebase.json
    │   ├── firestore.rules
    │   ├── package.json
    │   ├── tsconfig.json
    │   └── vitest.config.mjs
    ├── api-server/                  # current Health-only Express artifact
    └── mockup-sandbox/              # current component preview artifact
```

The archive also contains `ARCHIVE_FILE_LIST.txt`, a complete file list for the packaged snapshot.

## Dependencies and configuration

The current manifests are included unchanged:

- `workspace/package.json`
- `workspace/pnpm-lock.yaml`
- `workspace/pnpm-workspace.yaml`
- `workspace/artifacts/retail-business-manager/package.json`
- `workspace/artifacts/retail-business-manager/functions/package.json`
- `workspace/artifacts/retail-business-manager/functions/pnpm-lock.yaml`

The Functions package is independent from the Expo package. Its runtime dependencies are `firebase-admin` and `firebase-functions`; TypeScript is a development dependency. No application dependency was added for this handoff.

Firebase client configuration reads environment-variable names from `services/firebase.ts`. Values are not included.

## Current architecture

### Authentication

When Firebase configuration is present, the app uses Firebase Authentication through `services/firebase.ts` and `services/firebaseAuth.ts`. The current boundary supports email/password account creation, sign-in, sign-out, and Auth state restoration.

When Firebase is not configured, the existing local authenticated-state fallback remains available. The login UI was not changed for this handoff.

### Space Identity

`services/spaceIdentity.ts` creates or restores a local `SpaceIdentity` per Firebase UID and stores it in a UID-scoped AsyncStorage key. The local identity preserves the separation between Firebase UID, local `spaceId`, and `StoreProfile.id` / business `storeId`.

The local identity selects the local AsyncStorage namespace through `setActiveSpaceId`. It has not been deleted, renamed, replaced, or migrated.

### Multi-Space architecture

`types/space.ts` defines Space, Membership, OwnerMembership, Invitation, CloudOperation, and OperationReceipt contracts. A Space is the intended ownership and authorization boundary. `spaces/{spaceId}/members/{uid}` is the authorization source; `users/{uid}/memberships/{spaceId}` is only a discovery index.

Only primary-Space bootstrap is implemented. Additional Spaces, switching, invitations, and membership administration are not implemented.

### Trusted Bootstrap

The client service `services/trustedBootstrap.ts` calls the callable function `bootstrapPrimarySpace` with an empty request. It does not send UID, Space ID, owner ID, or role. It validates the response envelope and rejects malformed data instead of creating a local fallback Cloud identity.

The Functions source is under `functions/src/`:

- `index.ts` initializes Firebase Admin and exports only `bootstrapPrimarySpace` as a v2 callable.
- `bootstrapPrimarySpace.ts` derives UID from verified Auth context, generates or recovers the primary Space ID, and provisions server-owned records in one Firestore transaction.

The transaction covers the user primary-space marker, Space document, Owner Membership, membership discovery index, and operation receipt. It supports `created`, `existing`, and `repaired` outcomes and detects ownership conflicts.

### Firestore structure

```text
users/{uid}
users/{uid}/memberships/{spaceId}                 # discovery index only
spaces/{spaceId}
spaces/{spaceId}/members/{uid}                    # authorization source
operationReceipts/{operationId}
```

The legacy `services/firestore.ts` helper and `stores/{spaceId}` model remain in the source for compatibility/history, but the Auth flow no longer calls that helper. Bootstrap does not provision business data.

### Firestore Security Rules

`firestore.rules` currently provides:

- reads of `spaces/{spaceId}` only for signed-in users with an active Membership in that Space;
- reads of Space Membership documents only for active members;
- reads of a user's own membership index only when that user is active in the referenced Space;
- no client create/update/delete access for Spaces, Memberships, or membership indexes;
- explicit DENY for `customers`, `transactions`, `debts`, `payments`, `ledgerEntries`, `settlements`, `dailyClosings`, `operationReceipts`, and `auditEvents`;
- unchanged legacy `stores/{spaceId}` rules.

Rules do not inspect local `activeSpaceId`; local state cannot grant Cloud permission. Trusted Firebase Admin writes are separate from client Rules evaluation.

### Local storage

`services/storage.ts` owns AsyncStorage-backed local business data, including store profile, transactions, debts, payments, journals, archives, authenticated state, and Space-scoped namespaces. Bootstrap does not upload this data.

### StoreContext

`context/StoreContext.tsx` owns the current Auth/session boundary and local business state. On Auth transitions it clears in-memory business state, resolves the existing local Space Identity, bootstraps the Cloud Space, selects the local namespace, and then loads local profile/transactions. It does not start Sync, Outbox processing, Migration, or Cloud financial writes.

The returned Cloud Space is held separately as `cloudSpace`; it never replaces the local `SpaceIdentity`.

### Backup/Restore

`services/backupFile.ts` and the storage layer provide local, versioned backup/restore. Backup/Restore is independent of Firebase Cloud identity and Cloud Sync. No automatic Cloud import or migration occurs.

### Firebase Functions foundation

The standalone `functions/` package targets Node 20, has its own lockfile and TypeScript configuration, and is not a dependency of the Expo app. Only `bootstrapPrimarySpace` is exported. No Additional Space, invitation, membership-management, or financial-operation functions exist.

### API server

`artifacts/api-server` remains the existing Health-only Express artifact. It was not changed and is not the Firebase Admin boundary for bootstrap.

## Current project status

### IMPLEMENTED

- Expo Router mobile app with existing Arabic RTL-oriented product UI and local business flows.
- Firebase email/password Auth boundary and Auth state restoration.
- UID-scoped local `SpaceIdentity` persisted through AsyncStorage.
- Local namespace selection without changing Store IDs or moving legacy data.
- Existing local business data flows and modules.
- Local, versioned backup and restore with validation and isolation.
- Multi-Space domain contracts for Spaces, Memberships, invitations, operations, and receipts.
- Trusted Bootstrap request/response and provisioning contracts.
- Firebase Functions source for idempotent `bootstrapPrimarySpace` using Firebase Admin and a transaction.
- Client callable integration that receives the server Space as separate Cloud identity state.
- Membership-based Firestore Rules for the new Space paths.
- Explicit DENY for the listed business/financial Cloud paths.
- Unit coverage for local storage, Auth boundaries, contracts, bootstrap handler/client, and business behavior.

### DESIGNED BUT NOT IMPLEMENTED

- Additional Space creation contract and server operation.
- Space discovery and switching UI/behavior.
- Invitations and invitation acceptance lifecycle.
- Membership administration and role management.
- Trusted financial commands, append-only ledger, idempotency for financial mutations, and audit model.
- Future Cloud data schemas beyond bootstrap metadata.
- Production-grade notification/reminder flows.

### NOT STARTED

- Cloud Sync.
- Durable Outbox.
- Invitations.
- Member management.
- Additional Spaces.
- Financial Cloud Sync.
- Migration of local data.
- Automatic Cloud import from backups.
- Cloud writes for Customers, Transactions, Debts, Payments, Ledger Entries, Settlements, or Daily Closings.
- Production deployment of the new Functions flow.

## Important architectural decisions

These decisions must not be reversed accidentally:

1. Firebase UID is independent from `spaceId`.
2. `spaceId` is independent from `StoreProfile.id` and business `storeId`.
3. Local `SpaceIdentity` must remain intact and continue selecting local storage namespaces.
4. Local storage must not be deleted, renamed, or migrated automatically.
5. Membership inside `spaces/{spaceId}/members/{uid}` is the future authorization source.
6. `users/{uid}/memberships/{spaceId}` is a discovery index, not the authorization source.
7. Owner Membership and Space ownership must be controlled by the trusted backend.
8. Financial data must not be exposed through unrestricted client writes.
9. Backup/Restore remains independent from Cloud Sync.
10. Firebase Production data must not be used for development or testing.
11. Local `activeSpaceId` is a namespace selector, never proof of Cloud authorization.
12. Bootstrap identity fields are derived from verified Auth context, not accepted from the client body.

## Current task history

### Multi-Space domain contracts

**Implemented:** Space, Membership, OwnerMembership, Invitation, operation, and receipt contracts; role/status/mode values; separation of UID, Space ID, and Store ID.

**Intentionally not changed:** Local SpaceIdentity, AsyncStorage namespaces, business data, UI, API server, migration, and sync behavior.

**Known verification:** TypeScript passed; the contract-stage suite reported 17 test files and 147 passing tests.

### Trusted Bootstrap contracts

**Implemented:** Server-owned bootstrap request/response shapes, trusted Auth identity contract, provisioning write set, discovery index entry, outcomes, and error codes.

**Intentionally not changed:** No client UID/Space ID input, Additional Space operation, invitations, financial operation, or migration.

**Known verification:** TypeScript and contract tests passed at that stage.

### Firebase Functions foundation

**Implemented:** Standalone Functions package, Firebase Admin initialization, v2 callable export, transactional and idempotent primary-Space provisioning, and predeploy build configuration.

**Intentionally not changed:** `api-server`, app Auth flow, StoreContext, local storage, Security Rules, UI, Sync, Outbox, Migration, and business data uploads.

**Known verification:** Application and Functions TypeScript checks passed; bootstrap handler tests were added; the suite reached 18 test files and 151 passing tests.

### Client Trusted Bootstrap integration

**Implemented:** Callable client service, response validation, Auth-flow invocation, and separate `cloudSpace` state while preserving local `SpaceIdentity`.

**Intentionally not changed:** No local data movement, Sync, Migration, Additional Space, invitations, financial upload, UI, or API-server change.

**Known verification:** TypeScript passed; the suite reported 19 test files and 153 passing tests.

### Firestore Membership Security Rules

**Implemented:** Active-membership reads for new Space paths, deny-by-default client writes to Space/Membership structures, membership-index protection, and explicit financial-path DENY rules.

**Intentionally not changed:** StoreContext, SpaceIdentity, AsyncStorage, Backup/Restore, Auth, Functions, trustedBootstrap client, API server, packages, lockfiles, and `.replit`.

**Known verification:** TypeScript passed; available non-Emulator Unit Tests reported 19 test files and 153 passing tests. The Rules test source was updated but not executed.

## Next planned work

These are recommendations only and were not implemented in this archive:

1. Complete Multi-Space functionality while preserving the local namespace boundary.
2. Implement trusted Additional Space creation with server-owned IDs and idempotency.
3. Add Space discovery and switching without treating local `activeSpaceId` as authorization.
4. Add Invitations and server-controlled Membership management.
5. Add Notifications and reminders after ownership and privacy boundaries are defined.
6. Resolve important fixes found during real app testing before expanding Cloud behavior.
7. Add Cloud Sync selectively, only for approved data and after conflict/idempotency design.
8. Add Financial Cloud operations only after trusted commands, append-only ledger, idempotency, and audit foundations are approved.

## Test status

- **TypeScript:** Passing on the latest checked project state. The app root check includes the current TypeScript sources; the Functions package also passed its own TypeScript check during foundation work.
- **Unit tests:** Passing without Emulator: 19 test files, 153 tests passed at the latest recorded check.
- **Rules Emulator:** Not run. The Rules test source depends on `@firebase/rules-unit-testing`/Firestore Emulator tooling, and Java/Emulator tooling was not available. No tools were installed and `.replit` was not changed.
- **Firebase Production:** Not used.
- **E2E/Playwright:** Not used for the handoff task series.
- **Environment limitations:** Development workspace reports Node 24 while Functions targets Node 20; this produced an engine warning during dependency setup but did not block TypeScript checks. Emulator tooling remains unavailable.

## Security and secrets

No API-key values, Firebase service-account private keys, passwords, access tokens, authentication credentials, `.env` values, or Replit secret values are included.

Source/configuration references to environment-variable names are preserved where they are part of the application contract. Secret-like assignments in the copied `.replit` are represented as `<REDACTED>`.

## IMPORTANT FOR THE NEXT DEVELOPER / AI

This package represents the exact current state of the project at the snapshot date. Future work must:

- Read the existing architecture before changing anything.
- Preserve existing local data.
- Preserve Backup/Restore compatibility.
- Avoid unnecessary refactoring.
- Avoid changing established IDs or storage keys.
- Work in small, isolated tasks.
- Never implement Cloud Sync or Migration without explicit approval.
- Never use Firebase Production for tests.
- Preserve the separation between Firebase UID, Cloud Space ID, local SpaceIdentity, and Store ID.
- Treat Space Membership as the future authorization source and user membership indexes as discovery only.
- Stop and report architectural conflicts instead of silently changing established decisions.
