# Backup Restore Foundation

## What & Why

Add a small local Backup/Restore foundation for the current Retail Business Manager data. The backup must be self-contained, versioned, store-scoped, readable as a portable file, and safe to restore without touching the existing cash, journal, debt, payment, customer, or Archive behavior.

## Done looks like

- Settings contains only the necessary Backup and Restore actions.
- Backup creates a versioned JSON file containing the active store profile, store ID, currency/language settings, customers, transactions, debts, payments, all store Archives, and their immutable snapshots/closing numbers.
- Backup is read-only and does not alter any current record, balance, journal, closing, or Archive.
- The existing system share flow can share/save the generated backup file.
- Restore lets the user select a backup file, validates its format/version/required data/store ID/relationships before writing anything, and asks for confirmation before replacement.
- A valid backup for the active store restores the data and preserves relationships.
- A backup for another store, a malformed backup, an unsupported version, or incomplete data is rejected with a clear failure message.
- Restore preserves other stores' records and rolls back the affected storage keys if a write fails.
- The current working behavior of cash, currencies, transactions, debts, payments, Daily Journal, Multiple Closing, Archive, customer flows, Store Isolation, and WhatsApp Archive sharing is unchanged.
- Focused unit tests cover the requested backup/restore and safety cases.

## Out of scope

- Firebase, cloud backup, Google Drive, Cloud Storage, or remote synchronization.
- Login redesign, real authentication, Spaces/roles architecture, or a new database/data layer.
- Any change to Cash Box, currency calculations, transactions, debts, payments, Daily Journal, Archives, Multiple Closing, customer behavior, or Archive sharing semantics.
- Sales, Purchases, Inventory, Capital, Reports, or unrelated Settings redesign.
- Clearing all AsyncStorage, deleting unrelated stores, or silently migrating existing data.
- Expo preview, Browser, Playwright, Screenshots, or E2E verification.

## Steps

1. **Versioned local backup contract** — Define a minimal JSON backup envelope containing format version, creation timestamp, active store ID, StoreProfile, authentication/session setting needed by the current local app, and store-scoped operational collections. Keep currency settings in the profile and preserve every Archive snapshot and closing number exactly.
2. **Read/validate/restore service** — Add direct AsyncStorage helpers that read the current store-scoped data without mutation, serialize/parse the backup, validate every required collection and record shape, verify store ownership and customer/payment/debt relationships, and reject invalid or unsupported input before any write.
3. **Safe replacement** — Restore only the matching active store while preserving other stores' records and archive keys. Capture affected raw storage values first, write the prepared values, and restore the captured values on any failure; do not use `clear()` or broad deletion.
4. **Minimal Settings actions** — Add Backup and Restore controls to the existing Settings screen, use Expo's local file/share capabilities for the generated JSON file and document selection, show clear success/failure states, and confirm before replacing current data without redesigning Settings.
5. **Focused verification** — Add unit coverage for backup completeness/readability, round-trip restore, store isolation, multiple closings, debts/payments/customers/transactions/archives, invalid and unsupported files, rollback safety, unchanged balances, and relationship preservation. Run only TypeScript, unit tests, and `git diff --check`.

## Critical architectural constraints

- Keep `services/storage.ts` as the direct AsyncStorage boundary; do not introduce repositories, adapters, factories, or a broad data layer.
- Backup and restore must operate on the active `storeId`; a mismatched backup must be rejected rather than imported into another store.
- Archive data is copied/read as-is and never reconstructed through the close-day logic.
- Restore must be prepared and validated before replacement, with best-effort rollback if a write fails.
- Adding only the minimum Expo file/document dependencies needed for a real portable file is acceptable; do not add a cloud integration.

## Relevant files

- `artifacts/retail-business-manager/services/storage.ts`
- `artifacts/retail-business-manager/context/StoreContext.tsx`
- `artifacts/retail-business-manager/app/settings.tsx`
- `artifacts/retail-business-manager/types/business.ts`
- `artifacts/retail-business-manager/constants/i18n.ts`
- `artifacts/retail-business-manager/package.json`
- `pnpm-lock.yaml`
- `artifacts/retail-business-manager/tests/storage.test.ts`
- `artifacts/retail-business-manager/tests/archives.test.ts`
- `artifacts/retail-business-manager/tests/transactions.test.ts`
- `artifacts/retail-business-manager/tests/debts.test.ts`
- `artifacts/retail-business-manager/tests/settlements.test.ts`